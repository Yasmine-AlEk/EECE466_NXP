# Copyright 2024 NXP

# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0

import rclpy
from . import mrac_config as cfg
from rclpy.node import Node
from sensor_msgs.msg import Joy, LaserScan
from nav_msgs.msg import Odometry
from synapse_msgs.msg import EdgeVectors, TrafficStatus, Status

from .controllers.baseline_lane_controller import BaselineLaneController
from .debug.debug_snapshot import build_debug_snapshot
from .estimation.vehicle_state_estimator import VehicleStateEstimator
from .models.actuator_models import PropulsionForceModel, SteeringActuatorModel
from .models.dynamic_bicycle import DynamicBicycleModel
from .models.kinematic_bicycle import KinematicBicycleModel
from .models.outer_longitudinal_reduced import OuterLongitudinalReducedModel
from .models.outer_longitudinal_reference import OuterLongitudinalReferenceModel
from .models.state_space_vehicle import StateSpaceVehicleModel
from .models.wheel_force_decomposition import WheelForceDecompositionModel
from .mrac_config import (
    BATTERY_MAX_V,
    BATTERY_MIN_V,
    BATTERY_NOMINAL_V,
    DYNAMIC_BICYCLE_IZ_KG_M2,
    DYNAMIC_BICYCLE_LF_M,
    DYNAMIC_BICYCLE_LR_M,
    DYNAMIC_BICYCLE_MASS_KG,
    DYNAMIC_DRAG_FORCE_N,
    DYNAMIC_MODEL_MAX_DT_S,
    DYNAMIC_RAMP_FORCE_N,
    DYNAMIC_TIRE_FORCE_PAIR_COUNT,
    DYNAMIC_TORQUE_VECTORING_YAW_MOMENT_N_M,
    FRONT_CORNERING_STIFFNESS_N_PER_RAD,
    KINEMATIC_LF_M,
    KINEMATIC_LR_M,
    KINEMATIC_V_DEADZONE_MS,
    PROPULSION_EFFICIENCY,
    PROPULSION_FORCE_GAIN_N_PER_V,
    PROPULSION_FORCE_MAX_ABS_N,
    PROPULSION_MOTOR_TAU_S,
    PROPULSION_VOLTAGE_SAG_AT_FULL_PWM,
    QOS_PROFILE_DEFAULT,
    REAR_CORNERING_STIFFNESS_N_PER_RAD,
    REAR_TRACK_WIDTH_M,
    SLIP_ANGLE_MAX_ABS_RAD,
    SLIP_ANGLE_MIN_VX_MS,
    STEERING_SERVO_MAX_STEER_RAD,
    STEERING_SERVO_TAU_S,
    STATE_SPACE_K_DRAG_COEFF,
    STATE_SPACE_MIN_VX_MS,
    TIRE_FORCE_MAX_ABS_N,
    TORQUE_VECTORING_DFX_CMD_N,
)
from .mrac_types import (
    DynamicBicycleInput,
    DynamicBicycleState,
    KinematicBicycleState,
)
from .mrac_utils import turn_cmd_to_delta_f_est
from .perception.camera_measurements import CameraMeasurementExtractor


from .models.inner_lateral_yaw_reduced import InnerLateralYawReducedModel
from .models.inner_reference_command import InnerReferenceCommandModel
from .models.inner_lateral_yaw_reference import InnerLateralYawReferenceModel
from .models.speed_scheduler import FilteredSpeedScheduler
from .models.battery_gain_estimator import BatteryGainEstimator
from .models.cornering_stiffness_regression_outputs import CorneringStiffnessRegressionOutputModel
from .models.cornering_stiffness_regression_matrix import CorneringStiffnessRegressionMatrixModel
from .models.cornering_stiffness_rls_estimator import CorneringStiffnessRLSModel
from .models.cornering_stiffness_used_estimate import CorneringStiffnessUsedEstimateModel

class LineFollower(Node):
    """Line follower node with baseline control and MRAC/model scaffolding."""

    def __init__(self):
        super().__init__('line_follower')

        self.subscription_vectors = self.create_subscription(
            EdgeVectors,
            '/edge_vectors',
            self.edge_vectors_callback,
            QOS_PROFILE_DEFAULT
        )

        self.publisher_joy = self.create_publisher(
            Joy,
            '/cerebri/in/joy',
            QOS_PROFILE_DEFAULT
        )

        self.subscription_traffic = self.create_subscription(
            TrafficStatus,
            '/traffic_status',
            self.traffic_status_callback,
            QOS_PROFILE_DEFAULT
        )

        self.subscription_lidar = self.create_subscription(
            LaserScan,
            '/scan',
            self.lidar_callback,
            QOS_PROFILE_DEFAULT
        )

        self.subscription_odom = self.create_subscription(
            Odometry,
            '/cerebri/out/odometry',
            self.odometry_callback,
            QOS_PROFILE_DEFAULT
        )

        self.subscription_status = self.create_subscription(
            Status,
            '/cerebri/out/status',
            self.status_callback,
            QOS_PROFILE_DEFAULT
        )

        self.debug_timer = self.create_timer(
            0.5,
            self.debug_timer_callback
        )

        self.traffic_status = TrafficStatus()
        self.obstacle_detected = False
        self.ramp_detected = False

        self.estimator = VehicleStateEstimator()
        self.camera_extractor = CameraMeasurementExtractor()
        self.controller = BaselineLaneController()

        self.kinematic_model = KinematicBicycleModel(
            lf_m=KINEMATIC_LF_M,
            lr_m=KINEMATIC_LR_M
        )

        self.dynamic_model = DynamicBicycleModel(
            mass_kg=DYNAMIC_BICYCLE_MASS_KG,
            iz_kg_m2=DYNAMIC_BICYCLE_IZ_KG_M2,
            lf_m=DYNAMIC_BICYCLE_LF_M,
            lr_m=DYNAMIC_BICYCLE_LR_M,
            force_pair_count=DYNAMIC_TIRE_FORCE_PAIR_COUNT,
            max_dt_s=DYNAMIC_MODEL_MAX_DT_S,
            min_vx_for_slip_ms=SLIP_ANGLE_MIN_VX_MS,
            max_abs_slip_rad=SLIP_ANGLE_MAX_ABS_RAD,
            front_cornering_stiffness_n_per_rad=(
                FRONT_CORNERING_STIFFNESS_N_PER_RAD
            ),
            rear_cornering_stiffness_n_per_rad=(
                REAR_CORNERING_STIFFNESS_N_PER_RAD
            ),
            max_abs_tire_force_n=TIRE_FORCE_MAX_ABS_N,
        )

        self.steering_actuator_model = SteeringActuatorModel(
            tau_s=STEERING_SERVO_TAU_S,
            max_abs_delta_rad=STEERING_SERVO_MAX_STEER_RAD,
        )

        self.propulsion_model = PropulsionForceModel(
            tau_s=PROPULSION_MOTOR_TAU_S,
            efficiency=PROPULSION_EFFICIENCY,
            force_gain_n_per_v=PROPULSION_FORCE_GAIN_N_PER_V,
            voltage_sag_at_full_pwm_v=PROPULSION_VOLTAGE_SAG_AT_FULL_PWM,
            max_abs_force_n=PROPULSION_FORCE_MAX_ABS_N,
        )

        self.wheel_force_model = WheelForceDecompositionModel(
            rear_track_width_m=REAR_TRACK_WIDTH_M,
        )

        self.state_space_model = StateSpaceVehicleModel(
            mass_kg=DYNAMIC_BICYCLE_MASS_KG,
            iz_kg_m2=DYNAMIC_BICYCLE_IZ_KG_M2,
            lf_m=DYNAMIC_BICYCLE_LF_M,
            lr_m=DYNAMIC_BICYCLE_LR_M,
            rear_track_width_m=REAR_TRACK_WIDTH_M,
            c_alpha_f_n_per_rad=FRONT_CORNERING_STIFFNESS_N_PER_RAD,
            c_alpha_r_n_per_rad=REAR_CORNERING_STIFFNESS_N_PER_RAD,
            k_drag_coeff=STATE_SPACE_K_DRAG_COEFF,
            min_vx_ms=STATE_SPACE_MIN_VX_MS,
        )

        self.outer_longitudinal_model = OuterLongitudinalReducedModel(
            mass_kg=cfg.DYNAMIC_BICYCLE_MASS_KG,
            force_gain_n_per_v=cfg.PROPULSION_FORCE_GAIN_N_PER_V,
            efficiency=cfg.PROPULSION_EFFICIENCY,
            d_x_limit_ms2=cfg.OUTER_LONGITUDINAL_DX_LIMIT_MS2,
            k_v_loss_s=cfg.OUTER_LONGITUDINAL_K_V_S,
        )

        self.outer_reference_model = OuterLongitudinalReferenceModel(
            a_m_s_inv=cfg.OUTER_REFERENCE_A_M_S_INV,
            speed_cmd_to_vx_ref_gain=cfg.OUTER_REFERENCE_SPEED_CMD_TO_VX_GAIN,
            min_vx_ref_ms=cfg.OUTER_REFERENCE_MIN_VX_REF_MS,
            max_vx_ref_ms=cfg.OUTER_REFERENCE_MAX_VX_REF_MS,
            max_dt_s=cfg.OUTER_REFERENCE_MAX_DT_S,
        )

        self.inner_lateral_yaw_model = InnerLateralYawReducedModel(
            mass_kg=cfg.DYNAMIC_BICYCLE_MASS_KG,
            iz_kg_m2=cfg.DYNAMIC_BICYCLE_IZ_KG_M2,
            lf_m=cfg.DYNAMIC_BICYCLE_LF_M,
            lr_m=cfg.DYNAMIC_BICYCLE_LR_M,
            rear_track_width_m=cfg.REAR_TRACK_WIDTH_M,
            c_alpha_f_n_per_rad=cfg.FRONT_CORNERING_STIFFNESS_N_PER_RAD,
            c_alpha_r_n_per_rad=cfg.REAR_CORNERING_STIFFNESS_N_PER_RAD,
            min_vx_ms=cfg.INNER_LATERAL_YAW_MIN_VX_MS,
        )

        self.inner_reference_command_model = InnerReferenceCommandModel(
            kappa_from_ye_gain_1pm=cfg.INNER_REF_KAPPA_FROM_YE_GAIN_1PM,
            kappa_from_psi_gain_1pm=cfg.INNER_REF_KAPPA_FROM_PSI_GAIN_1PM,
            kappa_sign=cfg.INNER_REF_KAPPA_SIGN,
            max_abs_kappa_1pm=cfg.INNER_REF_MAX_ABS_KAPPA_1PM,
            max_abs_r_ref_rad_s=cfg.INNER_REF_MAX_ABS_R_REF_RAD_S,
            min_vx_ms=cfg.INNER_REF_MIN_VX_MS,
        )


        self.inner_speed_scheduler = FilteredSpeedScheduler(
            tau_s=cfg.INNER_SPEED_SCHEDULER_TAU_S,
            min_valid_vx_ms=cfg.INNER_LATERAL_YAW_MIN_VX_MS,
            max_dt_s=cfg.INNER_SPEED_SCHEDULER_MAX_DT_S,
        )

        self.latest_inner_lateral_yaw = None
        self.latest_inner_reference_command = None
        self.latest_camera_measurement = None
        self.latest_inner_speed_schedule = None

        self.inner_lateral_yaw_reference_model = InnerLateralYawReferenceModel(
            a_vy_s_inv=cfg.INNER_REFERENCE_MODEL_A_VY_S_INV,
            a_r_s_inv=cfg.INNER_REFERENCE_MODEL_A_R_S_INV,
            max_abs_uc_rad_s=cfg.INNER_REFERENCE_MODEL_MAX_ABS_UC_RAD_S,
            max_abs_vy_m_ms=cfg.INNER_REFERENCE_MODEL_MAX_ABS_VY_M_MS,
            max_abs_r_m_rad_s=cfg.INNER_REFERENCE_MODEL_MAX_ABS_R_M_RAD_S,
            max_dt_s=cfg.INNER_REFERENCE_MODEL_MAX_DT_S,
        )

        self.latest_inner_lateral_yaw_reference = None

        self.battery_gain_estimator = BatteryGainEstimator(
            b_nominal_ms2_per_pwm=cfg.BATTERY_GAIN_EST_NOMINAL_MS2_PER_PWM,
            tau_s=cfg.BATTERY_GAIN_EST_TAU_S,
            min_pwm=cfg.BATTERY_GAIN_EST_MIN_PWM,
            min_vx_ms=cfg.BATTERY_GAIN_EST_MIN_VX_MS,
            max_abs_r_rad_s=cfg.BATTERY_GAIN_EST_MAX_ABS_R_RAD_S,
            max_abs_delta_rad=cfg.BATTERY_GAIN_EST_MAX_ABS_DELTA_RAD,
            min_dt_s=cfg.BATTERY_GAIN_EST_MIN_DT_S,
            max_dt_s=cfg.BATTERY_GAIN_EST_MAX_DT_S,
            min_scale=cfg.BATTERY_GAIN_EST_MIN_SCALE,
            max_scale=cfg.BATTERY_GAIN_EST_MAX_SCALE,
        )

        self.cornering_regression_output_model = CorneringStiffnessRegressionOutputModel(
            min_dt_s=cfg.RLS_OUTPUT_MIN_DT_S,
            max_dt_s=cfg.RLS_OUTPUT_MAX_DT_S,
            filter_alpha=cfg.RLS_OUTPUT_FILTER_ALPHA,
            min_vx_ms=cfg.RLS_OUTPUT_MIN_VX_MS,
            max_abs_ay_ms2=cfg.RLS_OUTPUT_MAX_ABS_AY_MS2,
            max_abs_r_dot_rad_s2=cfg.RLS_OUTPUT_MAX_ABS_R_DOT_RAD_S2,
            rear_track_width_m=cfg.REAR_TRACK_WIDTH_M,
            iz_kg_m2=cfg.DYNAMIC_BICYCLE_IZ_KG_M2,
        )
        self.cornering_regression_matrix_model = CorneringStiffnessRegressionMatrixModel(
            mass_kg=cfg.DYNAMIC_BICYCLE_MASS_KG,
            iz_kg_m2=cfg.DYNAMIC_BICYCLE_IZ_KG_M2,
            lf_m=cfg.DYNAMIC_BICYCLE_LF_M,
            lr_m=cfg.DYNAMIC_BICYCLE_LR_M,
            min_vx_ms=cfg.RLS_MATRIX_MIN_VX_MS,
            min_excitation_norm=cfg.RLS_MATRIX_MIN_EXCITATION_NORM,
        )

        self.cornering_stiffness_rls_model = CorneringStiffnessRLSModel(
            initial_c_alpha_f=cfg.RLS_EST_INITIAL_C_ALPHA_F_N_PER_RAD,
            initial_c_alpha_r=cfg.RLS_EST_INITIAL_C_ALPHA_R_N_PER_RAD,
            p0=cfg.RLS_EST_INITIAL_COVARIANCE,
            lambda_forgetting=cfg.RLS_EST_LAMBDA,
            min_c_alpha=cfg.RLS_EST_MIN_C_ALPHA_N_PER_RAD,
            max_c_alpha=cfg.RLS_EST_MAX_C_ALPHA_N_PER_RAD,
            min_det=cfg.RLS_EST_MIN_DET,
            max_covariance=cfg.RLS_EST_MAX_COVARIANCE,
            min_update_vx_ms=cfg.RLS_PROTECT_MIN_UPDATE_VX_MS,
            min_abs_delta_rad=cfg.RLS_PROTECT_MIN_ABS_DELTA_RAD,
            min_abs_r_rad_s=cfg.RLS_PROTECT_MIN_ABS_R_RAD_S,
            min_phi_norm=cfg.RLS_PROTECT_MIN_PHI_NORM,
            max_abs_ycorr_0=cfg.RLS_PROTECT_MAX_ABS_YCORR_0,
            max_abs_ycorr_1=cfg.RLS_PROTECT_MAX_ABS_YCORR_1,
            update_every_n_ready=cfg.RLS_PROTECT_UPDATE_EVERY_N_READY,
            max_abs_parameter_step=cfg.RLS_PROTECT_MAX_ABS_PARAMETER_STEP,
            max_relative_parameter_step=cfg.RLS_PROTECT_MAX_RELATIVE_PARAMETER_STEP,
            sigma_pullback_alpha=cfg.RLS_PROTECT_SIGMA_PULLBACK_ALPHA,
        )

        self.cornering_stiffness_used_model = CorneringStiffnessUsedEstimateModel(
            nominal_c_alpha_f_n_per_rad=cfg.RLS_USED_NOMINAL_C_ALPHA_F_N_PER_RAD,
            nominal_c_alpha_r_n_per_rad=cfg.RLS_USED_NOMINAL_C_ALPHA_R_N_PER_RAD,
            min_c_alpha_n_per_rad=cfg.RLS_USED_MIN_C_ALPHA_N_PER_RAD,
            max_c_alpha_n_per_rad=cfg.RLS_USED_MAX_C_ALPHA_N_PER_RAD,
            ready_min_updates=cfg.RLS_USED_READY_MIN_UPDATES,
            max_p_trace=cfg.RLS_USED_MAX_P_TRACE,
            filter_alpha=cfg.RLS_USED_FILTER_ALPHA,
        )

        self.latest_cornering_regression_outputs = None
        self.latest_cornering_regression_matrix = None
        self.latest_cornering_stiffness_rls = None
        self.latest_cornering_stiffness_used = self.cornering_stiffness_used_model.current()

        self.latest_battery_gain_estimate = None

        self.kinematic_state_est = None
        self.latest_kinematic_derivative = None

        self.dynamic_state_est = None
        self.latest_dynamic_derivative = None
        self.latest_dynamic_input = None
        self.latest_slip_angles = None
        self.latest_tire_forces = None

        self.latest_steering_actuator = None
        self.latest_propulsion_actuator = None
        self.latest_wheel_forces = None
        self.latest_state_space = None
        self.latest_outer_longitudinal = None
        self.latest_outer_reference = None

        self.latest_debug_snapshot = None

        self.delta_ref_cmd_est = 0.0
        self.delta_f_cmd_est = 0.0
        self.a_long_cmd_est = 0.0

        self.last_speed_cmd = 0.0

    def rover_move_manual_mode(self, speed_cmd, turn_cmd):
        """Operates the rover in manual mode by publishing on /cerebri/in/joy."""
        msg = Joy()
        msg.buttons = [1, 0, 0, 0, 0, 0, 0, 1]
        msg.axes = [0.0, speed_cmd, 0.0, turn_cmd]
        self.publisher_joy.publish(msg)

    @staticmethod
    def clamp(value, min_value, max_value):
        return max(min_value, min(max_value, value))

    def estimate_battery_voltage(self):
        """
        Returns a simple battery-voltage estimate for the propulsion model.

        If fuel percentage exists:
            use it to interpolate between BATTERY_MIN_V and BATTERY_MAX_V.

        If not:
            use BATTERY_NOMINAL_V.
        """
        vehicle = self.estimator.vehicle

        if vehicle.battery_pct_meas is None:
            return BATTERY_NOMINAL_V

        pct = float(vehicle.battery_pct_meas)

        if pct > 1.0:
            pct = pct / 100.0

        pct = self.clamp(pct, 0.0, 1.0)

        return BATTERY_MIN_V + pct * (BATTERY_MAX_V - BATTERY_MIN_V)

    def update_actuator_models(self, speed_cmd: float, dt_s: float):
        """
        Task 2.5 / 2.6 actuator update.

        Steering:
            turn_cmd -> delta_ref -> first-order delta_f_est

        Propulsion:
            speed_cmd -> pwm_cmd -> first-order F_long_est
        """
        self.delta_ref_cmd_est = turn_cmd_to_delta_f_est(
            self.controller.last_turn_cmd
        )

        self.latest_steering_actuator = self.steering_actuator_model.step(
            delta_ref_rad=self.delta_ref_cmd_est,
            dt_s=dt_s,
        )

        self.delta_f_cmd_est = (
            self.latest_steering_actuator.delta_f_est_rad
        )

        battery_voltage_v = self.estimate_battery_voltage()

        self.latest_propulsion_actuator = self.propulsion_model.step(
            pwm_cmd=self.last_speed_cmd,
            battery_voltage_v=battery_voltage_v,
            dt_s=dt_s,
        )

    def update_debug_snapshot(self):
        self.latest_debug_snapshot = build_debug_snapshot(
            vehicle=self.estimator.vehicle,
            camera_measurement=self.camera_extractor.latest_camera_measurement,
            kinematic_state_est=self.kinematic_state_est,
            kinematic_derivative=self.latest_kinematic_derivative,
            dynamic_state_est=self.dynamic_state_est,
            dynamic_derivative=self.latest_dynamic_derivative,
            dynamic_input=self.latest_dynamic_input,
            slip_angles=self.latest_slip_angles,
            tire_forces=self.latest_tire_forces,
            steering_actuator=self.latest_steering_actuator,
            propulsion_actuator=self.latest_propulsion_actuator,
            wheel_forces=self.latest_wheel_forces,
            state_space=self.latest_state_space,
            inner_lateral_yaw=self.latest_inner_lateral_yaw,
            outer_longitudinal=self.latest_outer_longitudinal,
            outer_reference=self.latest_outer_reference,
            inner_reference_command=self.latest_inner_reference_command,
            inner_lateral_yaw_reference=self.latest_inner_lateral_yaw_reference,
            cornering_stiffness_outputs=self.latest_cornering_regression_outputs,
            cornering_stiffness_matrix=self.latest_cornering_regression_matrix,
            cornering_stiffness_rls=self.latest_cornering_stiffness_rls,
            cornering_stiffness_used=self.latest_cornering_stiffness_used,
            speed_cmd=self.last_speed_cmd,
            turn_cmd=self.controller.last_turn_cmd,
            delta_f_cmd_est=self.delta_f_cmd_est,
        )

    def update_outer_reference_model(self, speed_cmd: float, dt_s: float):
        """
        Task 4.1: update the desired longitudinal reference model.

        This does not change the actual command sent to the vehicle.
        It only creates vx_ref and vx_m for later MRAC tracking.
        """
        self.latest_outer_reference = (
            self.outer_reference_model.step_from_speed_cmd(
                speed_cmd=speed_cmd,
                dt_s=dt_s,
            )
        )

        self.update_debug_snapshot()

    def update_kinematic_bicycle_model(self, dt_s: float):
        """
        Runs the kinematic bicycle model in parallel.

        Now uses the lagged steering estimate delta_f_cmd_est instead of the
        instantaneous reference steering command.
        """
        vehicle = self.estimator.vehicle
        if not vehicle.odom_ready:
            return

        speed_for_model = vehicle.vx_recon

        if abs(speed_for_model) < KINEMATIC_V_DEADZONE_MS:
            speed_for_model = 0.0

        self.a_long_cmd_est = vehicle.a_long_filt

        measured_state = KinematicBicycleState(
            x=vehicle.x_meas,
            y=vehicle.y_meas,
            psi=vehicle.yaw_meas,
            v=max(0.0, speed_for_model)
        )

        self.latest_kinematic_derivative = self.kinematic_model.derivative(
            state=measured_state,
            delta_f_rad=self.delta_f_cmd_est,
            a_long_ms2=self.a_long_cmd_est
        )

        if self.kinematic_state_est is None:
            self.kinematic_state_est = measured_state
        else:
            self.kinematic_state_est, _ = self.kinematic_model.step_euler(
                state=self.kinematic_state_est,
                delta_f_rad=self.delta_f_cmd_est,
                a_long_ms2=self.a_long_cmd_est,
                dt_s=dt_s
            )

        self.update_debug_snapshot()

    def update_dynamic_bicycle_model(self, dt_s: float):
        """
        Runs the dynamic bicycle model in parallel.

        Now uses:
        - lagged steering angle from Task 2.5
        - propulsion force estimate from Task 2.6
        - tire forces from Task 2.4
        """
        vehicle = self.estimator.vehicle
        if not vehicle.odom_ready:
            return

        measured_state = DynamicBicycleState(
            x=vehicle.x_meas,
            y=vehicle.y_meas,
            psi=vehicle.yaw_meas,
            v_x=vehicle.vx_recon,
            v_y=vehicle.vy_recon,
            r=vehicle.r_recon,
        )

        self.latest_slip_angles = self.dynamic_model.compute_slip_angles(
            state=measured_state,
            delta_f_rad=self.delta_f_cmd_est,
        )

        self.latest_tire_forces = self.dynamic_model.compute_linear_tire_forces(
            slip_angles=self.latest_slip_angles,
        )

        if self.latest_propulsion_actuator is None:
            propulsion_force_n = 0.0
        else:
            propulsion_force_n = (
                self.latest_propulsion_actuator.force_longitudinal_est_n
            )

        self.latest_wheel_forces = self.wheel_force_model.decompose(
            f_long_n=propulsion_force_n,
            dfx_n=TORQUE_VECTORING_DFX_CMD_N,
        )

        longitudinal_force_n = (
            self.latest_wheel_forces.reconstructed_f_long_n
        )

        torque_vectoring_yaw_moment_n_m = (
            DYNAMIC_TORQUE_VECTORING_YAW_MOMENT_N_M
            + self.latest_wheel_forces.torque_vectoring_yaw_moment_n_m
        )

        self.latest_cornering_regression_outputs = self.cornering_regression_output_model.update(
            vx_ms=vehicle.vx_recon,
            vy_ms=vehicle.vy_recon,
            r_rad_s=vehicle.r_recon,
            dfx_n=self.latest_wheel_forces.dfx_n,
            dt_s=dt_s,
        )

        self.latest_cornering_regression_matrix = self.cornering_regression_matrix_model.build(
            vx_ms=vehicle.vx_recon,
            vy_ms=vehicle.vy_recon,
            r_rad_s=vehicle.r_recon,
            delta_f_rad=self.delta_f_cmd_est,
            outputs=self.latest_cornering_regression_outputs,
        )

        self.latest_cornering_stiffness_rls = self.cornering_stiffness_rls_model.update(
            self.latest_cornering_regression_matrix
        )

        self.latest_cornering_stiffness_used = self.cornering_stiffness_used_model.update(
            self.latest_cornering_stiffness_rls
        )

        self.latest_inner_speed_schedule = self.inner_speed_scheduler.update(
            raw_vx_ms=vehicle.vx_recon,
            dt_s=dt_s,
        )

        self.latest_inner_lateral_yaw = self.inner_lateral_yaw_model.build(
            vy_ms=vehicle.vy_recon,
            r_rad_s=vehicle.r_recon,
            vx0_ms=self.latest_inner_speed_schedule.vx0_ms,
            delta_f_rad=self.delta_f_cmd_est,
            dfx_n=self.latest_wheel_forces.dfx_n,
        )

        self.latest_state_space = self.state_space_model.build(
            vx_ms=vehicle.vx_recon,
            vy_ms=vehicle.vy_recon,
            r_rad_s=vehicle.r_recon,
            fx_left_n=self.latest_wheel_forces.fx_left_n,
            fx_right_n=self.latest_wheel_forces.fx_right_n,
            delta_f_rad=self.delta_f_cmd_est,
        )

        if self.latest_propulsion_actuator is not None:
            self.latest_outer_longitudinal = self.outer_longitudinal_model.build(
                vx_ms=vehicle.vx_recon,
                pwm_cmd=self.last_speed_cmd,
                battery_voltage_v=getattr(
                    self.latest_propulsion_actuator,
                    "battery_voltage_v",
                    cfg.BATTERY_NOMINAL_V,
                ),
                voltage_sag_v=getattr(
                    self.latest_propulsion_actuator,
                    "voltage_sag_v",
                    0.0,
                ),
                measured_vx_dot_ms2=vehicle.a_long_filt,
            )
            self.latest_battery_gain_estimate = (
                self.battery_gain_estimator.update(
                    vx_ms=vehicle.vx_recon,
                    pwm_cmd=self.last_speed_cmd,
                    measured_vx_dot_ms2=vehicle.a_long_filt,
                    k_v_loss_s=cfg.OUTER_LONGITUDINAL_K_V_S,
                    b_voltage_ms2_per_pwm=self.latest_outer_longitudinal.b_batt_est,
                    r_rad_s=vehicle.r_recon,
                    delta_f_rad=self.delta_f_cmd_est,
                    dt_s=dt_s,
                )
            )


        if (
            self.latest_camera_measurement is not None
            and self.latest_inner_lateral_yaw is not None
        ):
            self.latest_inner_reference_command = (
                self.inner_reference_command_model.build(
                    vx0_ms=self.latest_inner_lateral_yaw.vx0_safe_ms,
                    have_camera_measurement=(
                        self.latest_camera_measurement.have_measurement
                    ),
                    ye_cam_filt=self.latest_camera_measurement.ye_cam_filt,
                    psi_rel_cam_filt=(
                        self.latest_camera_measurement.psi_rel_cam_filt
                    ),
                )
            )

        uc_for_inner_reference_model = 0.0
        inner_reference_command_valid = False

        if self.latest_inner_reference_command is not None:
            uc_for_inner_reference_model = self.latest_inner_reference_command.uc_rad_s
            inner_reference_command_valid = self.latest_inner_reference_command.valid

        self.latest_inner_lateral_yaw_reference = (
            self.inner_lateral_yaw_reference_model.step(
                uc_rad_s=uc_for_inner_reference_model,
                dt_s=dt_s,
                command_valid=inner_reference_command_valid,
            )
        )

        model_input = DynamicBicycleInput(
            delta_f_rad=self.delta_f_cmd_est,
            longitudinal_force_n=longitudinal_force_n,
            front_lateral_force_n=(
                self.latest_tire_forces.front_lateral_force_n
            ),
            rear_lateral_force_n=(
                self.latest_tire_forces.rear_lateral_force_n
            ),
            drag_force_n=DYNAMIC_DRAG_FORCE_N,
            ramp_force_n=DYNAMIC_RAMP_FORCE_N,
            torque_vectoring_yaw_moment_n_m=(
                torque_vectoring_yaw_moment_n_m
            ),
        )

        self.latest_dynamic_input = model_input

        self.latest_dynamic_derivative = self.dynamic_model.derivative(
            state=measured_state,
            model_input=model_input,
        )

        if self.dynamic_state_est is None:
            self.dynamic_state_est = measured_state
        else:
            self.dynamic_state_est, _ = self.dynamic_model.step_euler(
                state=self.dynamic_state_est,
                model_input=model_input,
                dt_s=dt_s,
            )

        self.update_debug_snapshot()

    def edge_vectors_callback(self, message):
        vectors = message
        half_width = vectors.image_width / 2.0 if vectors.image_width > 0 else 1.0

        camera = self.camera_extractor.extract(vectors, half_width)
        self.latest_camera_measurement = camera

        turn_cmd, speed_cmd, dt_s = self.controller.compute(
            camera=camera,
            stop_sign=getattr(self.traffic_status, 'stop_sign', False),
            obstacle_detected=self.obstacle_detected,
            ramp_detected=self.ramp_detected,
        )

        self.last_speed_cmd = speed_cmd
        self.update_outer_reference_model(speed_cmd, dt_s)

        self.update_actuator_models(speed_cmd, dt_s)
        self.update_kinematic_bicycle_model(dt_s)
        self.update_dynamic_bicycle_model(dt_s)

        self.rover_move_manual_mode(speed_cmd, turn_cmd)

    def odometry_callback(self, message):
        prev_vx_recon = self.estimator.vehicle.vx_recon

        stamp = message.header.stamp
        current_odom_time_s = float(stamp.sec) + float(stamp.nanosec) * 1e-9
        previous_odom_time_s = getattr(self, "_debug_previous_odom_time_s", None)

        self.estimator.update_from_odometry(message)

        self.estimator.vehicle.vx_recon_prev = prev_vx_recon

        if previous_odom_time_s is None:
            self.estimator.vehicle.dt_odom = 0.0
        else:
            self.estimator.vehicle.dt_odom = max(
                0.0,
                current_odom_time_s - previous_odom_time_s,
            )

        self._debug_previous_odom_time_s = current_odom_time_s

    def status_callback(self, message):
        self.estimator.update_from_status(message)

    def debug_timer_callback(self):
        if not self.estimator.vehicle.odom_ready:
            self.get_logger().info("[MRAC scaffold] waiting for odometry...")
            return

        if self.latest_debug_snapshot is None:
            self.get_logger().info("[MRAC scaffold] waiting for first debug snapshot...")
            return

        if len(self.latest_debug_snapshot) == 0:
            self.get_logger().info("[MRAC scaffold] no debug fields enabled")
            return

        snapshot_to_print = list(self.latest_debug_snapshot)

        battery_gain = self.latest_battery_gain_estimate
        if battery_gain is not None:
            battery_debug_map = {
                "batt_gain_valid": (
                    f"batt_gain_valid={battery_gain.valid}"
                ),
                "batt_gain_update": (
                    f"batt_gain_update={battery_gain.update_enabled}"
                ),
                "batt_b_nom": (
                    f"batt_b_nom={battery_gain.b_nominal_ms2_per_pwm:.3f}"
                ),
                "batt_b_voltage": (
                    f"batt_b_voltage={battery_gain.b_voltage_ms2_per_pwm:.3f}"
                ),
                "batt_b_inst": (
                    f"batt_b_inst={battery_gain.b_inst_ms2_per_pwm:.3f}"
                ),
                "batt_b_hat": (
                    f"batt_b_hat={battery_gain.b_hat_ms2_per_pwm:.3f}"
                ),
                "batt_b_error": (
                    f"batt_b_error={battery_gain.b_error_ms2_per_pwm:.3f}"
                ),
                "batt_alpha": (
                    f"batt_alpha={battery_gain.alpha:.4f}"
                ),
                "batt_pred_vx_dot_hat": (
                    f"batt_pred_vx_dot_hat="
                    f"{battery_gain.predicted_vx_dot_from_hat_ms2:.3f}"
                ),
                "batt_reason": (
                    f"batt_reason={battery_gain.reason}"
                ),
            }

            for field_name in cfg.DEBUG_FIELDS:
                if field_name in battery_debug_map:
                    snapshot_to_print.append(battery_debug_map[field_name])

        self.get_logger().info("[MRAC scaffold] " + ", ".join(snapshot_to_print))

    def traffic_status_callback(self, message):
        self.traffic_status = message

    def lidar_callback(self, message):
        self.obstacle_detected = False
        self.ramp_detected = False
        return


def main(args=None):
    rclpy.init(args=args)
    line_follower = LineFollower()
    rclpy.spin(line_follower)
    line_follower.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
